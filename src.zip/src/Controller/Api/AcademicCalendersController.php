<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AcademicCalenders Controller
 *
 * @property \App\Model\Table\AcademicCalendersTable $AcademicCalenders
 *
 * @method \App\Model\Entity\AcademicCalender[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ApiController extends AppController
{

    
}
